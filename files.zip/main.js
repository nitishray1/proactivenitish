/* ============================================================
   MAIN.JS — Interactions & Animations
   nitishray.com / Nitish Ray
   No dependencies. Vanilla JS only.
   ============================================================ */

'use strict';

const $ = (s, c = document) => c.querySelector(s);
const $$ = (s, c = document) => [...c.querySelectorAll(s)];
const on = (el, e, fn, opts) => { if (el) el.addEventListener(e, fn, opts); };

/* ── NAV ─────────────────────────────────────────────────── */
const initNav = () => {
  const nav    = $('#nav');
  const toggle = $('#navToggle');
  const drawer = $('#navDrawer');
  if (!nav) return;

  on(window, 'scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 48);
  }, { passive: true });

  on(toggle, 'click', () => {
    const open = drawer.classList.toggle('open');
    toggle.classList.toggle('open', open);
    toggle.setAttribute('aria-expanded', open);
    document.body.style.overflow = open ? 'hidden' : '';
  });

  $$('#navDrawer a').forEach(a => {
    on(a, 'click', () => {
      drawer.classList.remove('open');
      toggle.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    });
  });

  on(document, 'click', e => {
    if (!nav.contains(e.target) && drawer.classList.contains('open')) {
      drawer.classList.remove('open');
      toggle.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    }
  });

  on(document, 'keydown', e => {
    if (e.key === 'Escape' && drawer.classList.contains('open')) {
      drawer.classList.remove('open');
      toggle.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
      toggle.focus();
    }
  });
};

/* ── REVEAL ──────────────────────────────────────────────── */
const initReveal = () => {
  const els = $$('.reveal');
  if (!els.length) return;
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    els.forEach(el => el.classList.add('visible'));
    return;
  }
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        obs.unobserve(e.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
  els.forEach(el => obs.observe(el));
};

/* ── FAQ ─────────────────────────────────────────────────── */
const initFaq = () => {
  $$('.faq__item').forEach(item => {
    const q = $('.faq__question', item);
    const a = $('.faq__answer', item);
    if (!q || !a) return;

    q.setAttribute('role', 'button');
    q.setAttribute('tabindex', '0');
    q.setAttribute('aria-expanded', 'false');

    const toggle = () => {
      const open = item.classList.contains('open');
      $$('.faq__item.open').forEach(i => {
        i.classList.remove('open');
        $('.faq__question', i)?.setAttribute('aria-expanded', 'false');
      });
      if (!open) {
        item.classList.add('open');
        q.setAttribute('aria-expanded', 'true');
      }
    };

    on(q, 'click', toggle);
    on(q, 'keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
    });
  });
};

/* ── SMOOTH SCROLL ───────────────────────────────────────── */
const initSmoothScroll = () => {
  $$('a[href^="#"]').forEach(a => {
    on(a, 'click', e => {
      const id = a.getAttribute('href');
      if (id === '#') return;
      const target = $(id);
      if (!target) return;
      e.preventDefault();
      const top = target.getBoundingClientRect().top + window.scrollY - 80;
      window.scrollTo({ top, behavior: 'smooth' });
      history.pushState(null, '', id);
    });
  });
};

/* ── ACTIVE NAV ──────────────────────────────────────────── */
const initActiveNav = () => {
  const sections = $$('section[id]');
  const links = $$('.nav__links a[href^="#"], .nav__drawer a[href^="#"]');
  if (!sections.length || !links.length) return;

  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        const id = e.target.id;
        links.forEach(l => l.classList.toggle('active', l.getAttribute('href') === `#${id}`));
      }
    });
  }, { threshold: 0.4 });
  sections.forEach(s => obs.observe(s));
};

/* ── MARQUEE ─────────────────────────────────────────────── */
const initMarquee = () => {
  const track = $('.marquee__track');
  if (!track) return;
  on(track, 'touchstart', () => { track.style.animationPlayState = 'paused'; }, { passive: true });
  on(track, 'touchend', () => { track.style.animationPlayState = 'running'; }, { passive: true });
};

/* ── TESTIMONIALS CAROUSEL ───────────────────────────────── */
const initCarousel = () => {
  const track = $('#testimonialsTrack');
  const dots  = $$('.testimonials__dot');
  if (!track || !dots.length) return;

  let current = 0;
  let startX  = 0;
  let dragging = false;
  const total = dots.length;

  const goTo = idx => {
    current = (idx + total) % total;
    track.style.transform = `translateX(-${current * 100}%)`;
    dots.forEach((d, i) => d.classList.toggle('active', i === current));
  };

  dots.forEach((d, i) => on(d, 'click', () => goTo(i)));

  on(track, 'mousedown', e => { startX = e.clientX; dragging = true; });
  on(document, 'mouseup', e => {
    if (!dragging) return;
    dragging = false;
    const diff = startX - e.clientX;
    if (Math.abs(diff) > 50) goTo(diff > 0 ? current + 1 : current - 1);
  });
  on(track, 'touchstart', e => { startX = e.touches[0].clientX; }, { passive: true });
  on(track, 'touchend', e => {
    const diff = startX - e.changedTouches[0].clientX;
    if (Math.abs(diff) > 50) goTo(diff > 0 ? current + 1 : current - 1);
  }, { passive: true });

  let auto = setInterval(() => goTo(current + 1), 6000);
  on(track, 'mousedown', () => clearInterval(auto));
  on(track, 'touchstart', () => clearInterval(auto), { passive: true });
};

/* ── YEAR ────────────────────────────────────────────────── */
const initYear = () => {
  const el = $('#currentYear');
  if (el) el.textContent = new Date().getFullYear();
};

/* ── INIT ────────────────────────────────────────────────── */
const init = () => {
  initNav();
  initReveal();
  initFaq();
  initSmoothScroll();
  initActiveNav();
  initMarquee();
  initCarousel();
  initYear();
};

if (document.readyState === 'loading') {
  on(document, 'DOMContentLoaded', init);
} else {
  init();
}
